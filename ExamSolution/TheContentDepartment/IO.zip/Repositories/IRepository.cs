﻿namespace TheContentDepartment.Repositories
{
    public interface IRepository
    {
    }
}