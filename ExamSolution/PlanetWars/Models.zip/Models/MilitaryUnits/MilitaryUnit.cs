﻿using System;
using System.Collections.Generic;
using System.Text;
using PlanetWars.Models.MilitaryUnits.Contracts;
using PlanetWars.Utilities.Messages;

namespace PlanetWars.Models.MilitaryUnits
{
    public abstract class MilitaryUnit : IMilitaryUnit
    {
        private double cost;
        private int endurancelevel;

        protected MilitaryUnit(double cost)
        {
            Cost = cost;
            this.endurancelevel = 1;
        }
        public double Cost
        {
            get => cost;
            private set
            {
                cost = value;
            }
        }

        public int EnduranceLevel => this.endurancelevel;
        public void IncreaseEndurance()
        {
            //•	Increases the endurance of the unit by 1 power point.
            // •	If exceeds 20, set the level to 20 and throw an ArgumentException with the message: "Endurance level cannot exceed 20 power points."
            // 
            if (endurancelevel == 20)
            {
               
                string.Format(ExceptionMessages.EnduranceLevelExceeded);
            }

            endurancelevel++;
           
        }
    }
}
