﻿namespace Formula1.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
