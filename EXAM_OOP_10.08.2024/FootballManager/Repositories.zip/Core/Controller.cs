﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FootballManager.Core.Contracts;
using FootballManager.Models;
using FootballManager.Models.Contracts;
using FootballManager.Repositories;
using FootballManager.Utilities.Messages;

namespace FootballManager.Core
{
    public class Controller : IController
    {
        private readonly TeamRepository championship;

        public Controller()
        {
            championship = new TeamRepository();
        }

        public string JoinChampionship(string teamName)
        {
            /*The method should create and add a new team to the TeamRepository.
               •	If the championship capacity is full (10 teams have joined the championship already), return the following message: "Championship is full!"
               •	If a team with the same name already exists, return the following message: "{name} has already joined the Championship."
               •	If the team is successfully created, add the team to the collection of teams and return: "{name} has successfully joined the Championship."
               */
            if (championship.Capacity <= championship.Models.Count)
            {
                return string.Format(OutputMessages.ChampionshipFull);
            }

            if (championship.Models.Any(x => x.Name == teamName))
            {
                return string.Format(OutputMessages.TeamWithSameNameExisting, teamName);
            }

            ITeam team = new Team(teamName);
            championship.Add(team);
            return string.Format(OutputMessages.TeamSuccessfullyJoined, teamName);
        }

        public string SignManager(string teamName, string managerTypeName, string managerName)
        {
            /*The method should create and set a new Manager for the specified team.
               •	If the given teamName  is NOT presented in the Championship, return the following message: "Team {teamName} does not take part in the Championship."
               •	If the given managerTypeName is not a valid Manager subclass (AmateurManager, SeniorManager, or ProfessionalManager), return the message:
            "{managerTypeName} is an invalid manager type for the application."
               •	If the team has already signed with another manager, return the message: "Team {teamName} has already signed a contract with {currentManagerName}."
               •	Iterate through all teams (with managers) in the Championship to check if any team has already signed a contract with a manager with the same name.
            If another team has already signed a contract with the manager, return the message: "Manager {managerName} is already assigned to another team."
               •	If none of the above cases is reached, create the correct type of IManager, based on the managerTypeName, and assign the manager to the team using the appropriate method. 
            Return the following message: "Manager {managerName} is assigned to team {teamName}."
               */
            ITeam team = championship.Get(teamName);
            if (team == null)
            {
                return string.Format(OutputMessages.TeamDoesNotTakePart, teamName);

            }
            IManager manager;

            if (managerTypeName == "AmateurManager")

                manager = new AmateurManager(managerName);

            else if (managerTypeName == "SeniorManager")

                manager = new SeniorManager(managerName);

            else if (managerTypeName == "ProfessionalManager")

                manager = new ProfessionalManager(managerName);
            else
                return $"{managerTypeName} is an invalid manager type for the application.";


            if (team.TeamManager != null)
            {
                return string.Format(OutputMessages.TeamSignedWithAnotherManager, teamName, team.TeamManager.Name);
            }
            foreach (var currenTeam in championship.Models)
            {
                if (currenTeam.TeamManager != null && currenTeam.TeamManager.Name == managerName)
                {

                    return string.Format(OutputMessages.ManagerAssignedToAnotherTeam, managerName);
                }
            }
            team.SignWith(manager);
            return string.Format(OutputMessages.TeamSuccessfullySignedWithManager, managerName, teamName);

        }

        public string MatchBetween(string teamOneName, string teamTwoName)
        {
            /*The MatchBetween method simulates a match between two teams and determines the winner based on their present condition:
               •	Check if both teams, identified by teamOneName and teamTwoName take part in the Championship. 
            If either team does not take part, return the following message: "This match does not meet the regulation rules of the Championship."
               •	Compare the present condition of the two teams. The team in the better condition wins the game.
            Increment the ChampionshipPoints of the winning team by 3 points. 
               o	If the winning team has a working manager, increase the winning team manager's ranking by 5 units.
               o	If the losing team has a working manager, decrease the losing team manager's ranking by 5 units.
               o	Return the following message: "Team {winningTeamName} wins the match against {losingTeamName}."
               •	If the present conditions of both teams are equal, increment the ChampionshipPoints of both teams by 1 point.
               o	Return the following messase: "The match between {teamOneName} and {teamTwoName} ends in a draw."
               */
            ITeam teamOne = championship.Get(teamOneName);
            ITeam teamTwo = championship.Get(teamTwoName);

            if (teamOne == null || teamTwo == null)
            {
                return "This match does not meet the regulation rules of the Championship.";
            }

            int teamOneCondition = teamOne.PresentCondition;
            int teamTwoCondition = teamTwo.PresentCondition;

            if (teamOneCondition > teamTwoCondition)
            {
                teamOne.GainPoints(3);

                if (teamOne.TeamManager != null)
                {
                    teamOne.TeamManager.RankingUpdate(5);
                }

                if (teamTwo.TeamManager != null)
                {
                    teamTwo.TeamManager.RankingUpdate(-5);
                }

                return $"Team {teamOne.Name} wins the match against {teamTwo.Name}.";
            }
            else if (teamTwoCondition > teamOneCondition)
            {
                teamTwo.GainPoints(3);

                if (teamTwo.TeamManager != null)
                {
                    teamTwo.TeamManager.RankingUpdate(5);
                }

                if (teamOne.TeamManager != null)
                {
                    teamOne.TeamManager.RankingUpdate(-5);
                }

                return $"Team {teamTwo.Name} wins the match against {teamOne.Name}.";
            }
            else
            {
                teamOne.GainPoints(1);
                teamTwo.GainPoints(1);

                return $"The match between {teamOne.Name} and {teamTwo.Name} ends in a draw.";
            }
        }

        public string PromoteTeam(string droppingTeamName, string promotingTeamName, string managerTypeName, string managerName)
        {
            /*The PromoteTeam method simulates the promotion of one team and the demotion of another team in the Football Manager application.
             The method performs the following steps:
               •	Check if the team identified by droppingTeamName competes in the Championship (exists in the TeamRepository).
            If the team does not exist, return the following message: "Team {droppingTeamName} does not exist in the Championship."
               •	If a team with the same promotingTeamName already exists, return the following message: "{name} has already joined the Championship."
               •	Create a new team with the given promotingTeamName.
               •	Iterate through all teams in the Championship to check if any team has already signed a contract with a manager with the same name.
            If another team has already signed a contract with the manager OR the given managerTypeName
            is not a valid Manager subclass (AmateurManager, SeniorManager, or ProfessionalManager), leave the new team without a manager.
               •	Create a new manager, with the given managerName, and assign the new manager to the new team.
               •	The promotions always happen before starting a new Championship season, so all the teams have their ChampionshipPoints reset. 
               •	Remove the team with the given droppingTeamName from the Championship.
               •	Add the new team to compete in the championship, and return the following message: "Team {promotingTeamName} wins a promotion for the new season."
               */
            ITeam team = championship.Get(droppingTeamName);
            if (team == null)
            {
                return string.Format(OutputMessages.DroppingTeamDoesNotExist, droppingTeamName);
            }

            if (championship.Models.Any(x => x.Name == promotingTeamName))
            {
                return string.Format(OutputMessages.TeamWithSameNameExisting, promotingTeamName);
            }

            ITeam promotionTeam = new Team(promotingTeamName);

            bool managerAssigned = false;
            IManager manager = null;
            foreach (var currentTeam in championship.Models)
            {
                if (currentTeam.TeamManager != null && currentTeam.TeamManager.Name == managerName)
                {
                    managerAssigned = true;
                    break;
                }
            }
            if (!managerAssigned)
            {
                if (managerTypeName == nameof(AmateurManager))
                    manager = new AmateurManager(managerName);

                if (managerTypeName == nameof(SeniorManager))
                    manager = new SeniorManager(managerName);

                if (managerTypeName == nameof(ProfessionalManager))
                    manager = new ProfessionalManager(managerName);

                if (manager != null)
                {
                    promotionTeam.SignWith(manager);
                }
            }
            foreach (var currentsTeam in championship.Models)
            {
                currentsTeam.ResetPoints();
            }
            championship.Remove(droppingTeamName);

            
            championship.Add(promotionTeam);

            return string.Format(OutputMessages.TeamHasBeenPromoted, promotingTeamName);

        }

        public string ChampionshipRankings()
        {
            /*Returns the current ranking table of the Championship.
             The teams are ordered by ChampionshipPoints, in descending order, then by their PresentCondition, also in descending order.
            For every team, there should be information for the team's manager. 
            In order to receive the correct output, use the ToString() method of each team and manager:
               "***Ranking Table***
               1. {team1}/{teamManager}
               2. {team2}/{teamManager}
               3. {team3}/{teamManager}
               4. {team4}/{teamManager}
               …
               'n'. {teamn}/{teamManager}"
               */
            var orderedTeams = championship.Models
                .OrderByDescending(x => x.ChampionshipPoints)
                .ThenByDescending(x => x.PresentCondition)
                .ToList();
            var sb = new StringBuilder();
            sb.AppendLine("***Ranking Table***");
            for (int i = 0; i < orderedTeams.Count(); i++)
            {
                var team = orderedTeams[i];
                sb.AppendLine($"{i+1}. {team}/{(team.TeamManager != null ? team.TeamManager.ToString() : "No Manager")}");
                
            }
            return sb.ToString().TrimEnd();
        }
       
    }
}


